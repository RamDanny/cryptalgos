from censys.search import CensysHosts
from censys.search import SearchClient
import plotly.express as px

c = SearchClient()
h = CensysHosts()

def get_ncren():
    results = []
    query = h.search('(NC State University) and autonomous_system.name=`NCREN`')
    for q in query():
        if q.get('dns'):
            for string in q['dns']['reverse_dns']['names']:
                if 'ncsu.edu' in string:
                    results.append(q)
    for r in results:
        print(r, end='\n')

get_ncren()
