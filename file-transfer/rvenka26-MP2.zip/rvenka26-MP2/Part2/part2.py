from censys.search import CensysHosts
from censys.search import SearchClient
import plotly.express as px

c = SearchClient()
h = CensysHosts()

def aggregate(query, field):
    data = {'x': [], 'y': []}
    results = c.v2.hosts.aggregate(query, field)
    for entry in results['buckets']:
        data['x'].append(entry['key'])
        data['y'].append(entry['count'])
    return data

def order_by_os():
    data = aggregate('ip: 152.1.0.0/16 or ip: 152.7.0.0/16 or ip: 152.14.0.0/16 or ip: 192.58.122.0/24', 'operating_system.product')
    fig = px.bar(data, x='x', y='y', title='Hosts by OS', labels={'x': 'Operating System', 'y': 'Count'}, color='x')
    fig.show()

def order_by_web_server():
    data = aggregate('ip: 152.1.0.0/16 or ip: 152.7.0.0/16 or ip: 152.14.0.0/16 or ip: 192.58.122.0/24', 'services.software.product')
    fig = px.bar(data, x='x', y='y', title='Hosts by Web Server', labels={'x': 'Product', 'y': 'Count'}, color='x')
    fig.show()

def order_by_protocol():
    data = aggregate('ip: 152.1.0.0/16 or ip: 152.7.0.0/16 or ip: 152.14.0.0/16 or ip: 192.58.122.0/24', 'services.service_name')
    fig = px.bar(data, x='x', y='y', title='Hosts by Protocol', labels={'x': 'Protocol', 'y': 'Count'}, color='x')
    fig.show()

def order_by_os_smtp():
    data = aggregate('services.service_name: SMTP and (ip: 152.1.0.0/16 or ip: 152.7.0.0/16 or ip: 152.14.0.0/16 or ip: 192.58.122.0/24)', 'operating_system.product')
    fig = px.bar(data, x='x', y='y', title='Hosts with SMTP by Operating System', labels={'x': 'Operating System', 'y': 'Count'}, color='x')
    fig.show()

def order_by_os_8080():
    data = aggregate('services.port: 8080 AND services.service_name: "http" and (ip: 152.1.0.0/16 or ip: 152.7.0.0/16 or ip: 152.14.0.0/16 or ip: 192.58.122.0/24)', 'operating_system.product')
    fig = px.bar(data, x='x', y='y', title='Hosts with port 8080 open by Operating System', labels={'x': 'Operating System', 'y': 'Count'}, color='x')
    fig.show()

def order_by_service_linux():
    data = aggregate('operating_system.product: linux and (ip: 152.1.0.0/16 or ip: 152.7.0.0/16 or ip: 152.14.0.0/16 or ip: 192.58.122.0/24)', 'services.service_name')
    fig = px.bar(data, x='x', y='y', title='Hosts with Linux by Protocol', labels={'x': 'Protocol', 'y': 'Count'}, color='x')
    fig.show()

#order_by_os()
#order_by_web_server()
#order_by_protocol()
#order_by_os_smtp()
#order_by_os_8080()
#order_by_service_linux()
